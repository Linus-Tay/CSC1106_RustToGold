pub mod renderer;
pub mod templates;

pub use self::renderer::render;
pub use self::templates::{
    AboutTemplate, AdminFixedDepositPlansTemplate, AdminFixedDepositsTemplate, AdminHomeLoansTemplate,
    BankingTemplate, ContactTemplate, CustomerPageTemplate, DashboardTemplate, DepositTemplate,
    ErrorTemplate, FaqTemplate, FixedDepositCreateTemplate, FixedDepositDashboardTemplate,
    ForbiddenTemplate, HomeLoanApplyTemplate, HomeLoanDashboardTemplate, HomeTemplate, LoginTemplate,
    LoanApplyTemplate, LoanDashboardTemplate, NotFoundTemplate, OnboardingFormTemplate,
    OnboardingFormTemplate1, OnboardingResultTemplate, OnboardingTemplate, ProfileTemplate,
    SecurityTemplate, SignupAccountTemplate, SignupContactTemplate, SignupEmploymentTemplate,
    SignupPersonalTemplate, SignupReviewTemplate, SignupSecurityTemplate, SignupTemplate,
    TransactionsTemplate, TransferTemplate,
};
