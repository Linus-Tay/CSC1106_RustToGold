use crate::forms::{AccountCreationForm, LoginForm};
use crate::models::User;
use crate::repositories::{customer_repository, user_repository};
use actix_web::Error;
use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use sqlx::PgPool;
use uuid::Uuid;

pub async fn register_user(
    db: &PgPool,
    customer_id: &Uuid,
    customer_email: &str,
    form: AccountCreationForm,
) -> Result<User, String> {
    let username = form.username.trim().to_lowercase();

    if username.len() < 4 {
        return Err("Username must be at least 4 characters.".to_string());
    }

    if form.password.len() < 8 {
        return Err("Password must be at least 8 characters.".to_string());
    }

    if form.password != form.confirm_password {
        return Err("Passwords do not match.".to_string());
    }

    if user_repository::find_user_by_login(db, &username)
        .await
        .map_err(|_| "Could not check username availability.".to_string())?
        .is_some()
    {
        return Err("This username is already in use.".to_string());
    }

    let customer = customer_repository::get_customer_by_id(db, customer_id)
        .await
        .map_err(|_| "Could not load the approved customer profile.".to_string())?;

    let password_hash = hash_password(&form.password).map_err(|_| "Cannot create user".to_string())?;

    user_repository::create_customer_user(
        db,
        customer.id,
        &username,
        customer_email,
        &password_hash,
    )
    .await
    .map_err(|error| {
        eprintln!("Error creating online banking user: {error:?}");
        "Could not create online banking user.".to_string()
    })
}

pub async fn authenticate_user(db: &PgPool, form: LoginForm) -> Result<User, String> {
    let login = form.username.trim().to_lowercase();

    let user = user_repository::find_user_by_login(db, &login)
        .await
        .map_err(|error| {
            eprintln!("LOGIN lookup failed for {login}: {error:?}");
            "Could not load your account.".to_string()
        })?
        .ok_or_else(|| "Invalid username/email or password.".to_string())?;

    if !user.is_active() {
        return Err("This account is not active.".to_string());
    }

    if !verify_password(&form.password, &user.password_hash) {
        return Err("Invalid username/email or password.".to_string());
    }

    user_repository::update_last_login(db, user.id)
        .await
        .map_err(|error| {
            eprintln!(
                "LOGIN last-login update failed for user_id {}: {:?}",
                user.id, error
            );
            "Login succeeded, but the last-login timestamp could not be updated.".to_string()
        })?;

    Ok(user)
}

fn hash_password(password: &str) -> Result<String, Error> {
    let salt = SaltString::generate(&mut OsRng);
    let hash = Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map_err(actix_web::error::ErrorInternalServerError)?;
    Ok(hash.to_string())
}

fn verify_password(password: &str, password_hash: &str) -> bool {
    PasswordHash::new(password_hash)
        .ok()
        .and_then(|parsed_hash| {
            Argon2::default()
                .verify_password(password.as_bytes(), &parsed_hash)
                .ok()
        })
        .is_some()
}


