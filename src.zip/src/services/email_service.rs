use crate::Config;
use askama::DynTemplate;
use lettre::message::{header::ContentType, Message, SinglePart};
use lettre::transport::smtp::authentication::Credentials;
use lettre::{AsyncSmtpTransport, AsyncTransport, Tokio1Executor};
use std::env;

pub async fn send_template_email(
    to_email: &str,
    subject: &str,
    template_data: &dyn DynTemplate,
) -> Result<(), Box<dyn std::error::Error>> {
    let smtp_host = match env::var("SMTP_HOST") {
        Ok(value) if !value.trim().is_empty() => value,
        _ => {
            eprintln!("EMAIL SKIPPED: SMTP_HOST is not configured. Subject: {subject}, To: {to_email}");
            return Ok(());
        }
    };

    let smtp_username = match env::var("SMTP_USERNAME") {
        Ok(value) if !value.trim().is_empty() => value,
        _ => {
            eprintln!("EMAIL SKIPPED: SMTP_USERNAME is not configured. Subject: {subject}, To: {to_email}");
            return Ok(());
        }
    };

    let smtp_password = match env::var("SMTP_PASSWORD") {
        Ok(value) if !value.trim().is_empty() => value,
        _ => {
            eprintln!("EMAIL SKIPPED: SMTP_PASSWORD is not configured. Subject: {subject}, To: {to_email}");
            return Ok(());
        }
    };

    let config = Config::from_env();
    let html_body = template_data.dyn_render()?;

    let email = Message::builder()
        .from(smtp_username.parse()?)
        .to(to_email.parse()?)
        .subject(subject)
        .singlepart(
            SinglePart::builder()
                .header(ContentType::TEXT_HTML)
                .body(html_body),
        )?;

    let creds = Credentials::new(smtp_username, smtp_password);

    let mailer: AsyncSmtpTransport<Tokio1Executor> =
        AsyncSmtpTransport::<Tokio1Executor>::starttls_relay(&smtp_host)?
            .port(config.smtp_port)
            .credentials(creds)
            .build();

    mailer.send(email).await?;
    Ok(())
}
