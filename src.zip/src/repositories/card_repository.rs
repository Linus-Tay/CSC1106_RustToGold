use crate::models::Card;
use sqlx::PgPool;
use uuid::Uuid;

pub async fn list_cards_by_customer(db: &PgPool, customer_id: Uuid) -> Result<Vec<Card>, sqlx::Error> {
    sqlx::query_as::<_, Card>(
        r#"
        SELECT c.id, c.customer_id, c.linked_product_id, cp.account_number,
               c.card_type, c.display_name, c.masked_number, c.status, c.created_at, c.updated_at
        FROM cards c
        JOIN customer_products cp ON cp.id = c.linked_product_id
        WHERE c.customer_id = $1
        ORDER BY c.created_at DESC
        "#,
    )
    .bind(customer_id)
    .fetch_all(db)
    .await
}

pub async fn create_card(
    db: &PgPool,
    customer_id: Uuid,
    linked_product_id: Uuid,
    card_type: &str,
    display_name: &str,
    masked_number: &str,
) -> Result<Card, sqlx::Error> {
    sqlx::query_as::<_, Card>(
        r#"
        INSERT INTO cards (customer_id, linked_product_id, card_type, display_name, masked_number, status)
        VALUES ($1, $2, $3, $4, $5, 'active')
        RETURNING id, customer_id, linked_product_id,
            (SELECT account_number FROM customer_products WHERE id = $2) AS account_number,
            card_type, display_name, masked_number, status, created_at, updated_at
        "#,
    )
    .bind(customer_id)
    .bind(linked_product_id)
    .bind(card_type)
    .bind(display_name)
    .bind(masked_number)
    .fetch_one(db)
    .await
}

pub async fn set_card_status(
    db: &PgPool,
    customer_id: Uuid,
    card_id: Uuid,
    status: &str,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        r#"
        UPDATE cards
        SET status = $1, updated_at = NOW()
        WHERE id = $2 AND customer_id = $3
        "#,
    )
    .bind(status)
    .bind(card_id)
    .bind(customer_id)
    .execute(db)
    .await?;

    Ok(())
}
