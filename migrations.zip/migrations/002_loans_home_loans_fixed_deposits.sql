-- RustToGold account-creation add-on
-- Adds personal loans, home loans, fixed deposits, and transaction types.
-- Run this after the account-creation 001 migration.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
DECLARE
    tx_type_constraint TEXT;
BEGIN
    SELECT c.conname
    INTO tx_type_constraint
    FROM pg_constraint c
    JOIN pg_class t ON t.oid = c.conrelid
    JOIN pg_namespace n ON n.oid = t.relnamespace
    WHERE t.relname = 'transactions'
      AND c.contype = 'c'
      AND pg_get_constraintdef(c.oid) ILIKE '%transaction_type%'
    LIMIT 1;

    IF tx_type_constraint IS NOT NULL THEN
        EXECUTE format('ALTER TABLE transactions DROP CONSTRAINT %I', tx_type_constraint);
    END IF;
END $$;

ALTER TABLE transactions
ADD CONSTRAINT transactions_transaction_type_check
CHECK (
    transaction_type IN (
        'deposit',
        'withdrawal',
        'transfer_in',
        'transfer_out',
        'loan_disbursement',
        'loan_payment',
        'home_loan_payment',
        'fixed_deposit_open',
        'fixed_deposit_withdrawal',
        'fixed_deposit_payout'
    )
);

-- Backfill customer_products for accounts created before this patch.
INSERT INTO customer_products (
    customer_id,
    product_id,
    product_type,
    account_number,
    status,
    balance_cents,
    created_at,
    updated_at
)
SELECT
    u.customer_id,
    ba.account_type,
    'savings',
    ba.account_number,
    CASE
        WHEN ba.status = 'active' THEN 'active'
        WHEN ba.status = 'closed' THEN 'closed'
        ELSE 'inactive'
    END,
    ba.balance_cents,
    ba.created_at,
    ba.updated_at
FROM bank_accounts ba
JOIN users u ON u.id = ba.user_id
WHERE NOT EXISTS (
    SELECT 1
    FROM customer_products cp
    WHERE cp.account_number = ba.account_number
);

CREATE TABLE IF NOT EXISTS personal_loans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    funding_product_id UUID NOT NULL REFERENCES customer_products(id) ON DELETE RESTRICT,
    purpose TEXT NOT NULL,
    principal_cents BIGINT NOT NULL CHECK (principal_cents > 0),
    annual_rate_bps INTEGER NOT NULL CHECK (annual_rate_bps > 0),
    term_months INTEGER NOT NULL CHECK (term_months BETWEEN 1 AND 120),
    monthly_payment_cents BIGINT NOT NULL CHECK (monthly_payment_cents > 0),
    outstanding_cents BIGINT NOT NULL CHECK (outstanding_cents >= 0),
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'fully_paid', 'cancelled')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_personal_loans_customer_id
ON personal_loans(customer_id);

CREATE TABLE IF NOT EXISTS home_loan_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    account_product_id UUID REFERENCES customer_products(id) ON DELETE SET NULL,
    property_type TEXT NOT NULL,
    property_value_cents BIGINT NOT NULL CHECK (property_value_cents > 0),
    down_payment_cents BIGINT NOT NULL CHECK (down_payment_cents >= 0),
    loan_amount_cents BIGINT NOT NULL CHECK (loan_amount_cents > 0),
    annual_rate_bps INTEGER NOT NULL CHECK (annual_rate_bps > 0),
    term_years INTEGER NOT NULL CHECK (term_years BETWEEN 1 AND 40),
    monthly_payment_cents BIGINT NOT NULL CHECK (monthly_payment_cents > 0),
    outstanding_cents BIGINT NOT NULL DEFAULT 0 CHECK (outstanding_cents >= 0),
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'approved', 'rejected', 'fully_paid')),
    reviewed_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    reviewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (down_payment_cents < property_value_cents)
);

CREATE INDEX IF NOT EXISTS idx_home_loan_applications_customer_id
ON home_loan_applications(customer_id);

CREATE INDEX IF NOT EXISTS idx_home_loan_applications_status
ON home_loan_applications(status);

CREATE TABLE IF NOT EXISTS fixed_deposit_plans (
    id BIGSERIAL PRIMARY KEY,
    plan_name TEXT NOT NULL,
    tenure_months INTEGER NOT NULL CHECK (tenure_months BETWEEN 1 AND 60),
    annual_rate_bps INTEGER NOT NULL CHECK (annual_rate_bps BETWEEN 1 AND 1000),
    minimum_amount_cents BIGINT NOT NULL CHECK (minimum_amount_cents > 0),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fixed_deposits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    funding_product_id UUID NOT NULL REFERENCES customer_products(id) ON DELETE RESTRICT,
    plan_id BIGINT NOT NULL REFERENCES fixed_deposit_plans(id) ON DELETE RESTRICT,
    principal_cents BIGINT NOT NULL CHECK (principal_cents > 0),
    annual_rate_bps INTEGER NOT NULL CHECK (annual_rate_bps > 0),
    tenure_months INTEGER NOT NULL CHECK (tenure_months BETWEEN 1 AND 60),
    interest_cents BIGINT NOT NULL CHECK (interest_cents >= 0),
    maturity_date DATE NOT NULL,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'matured', 'withdrawn', 'paid_out')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fixed_deposits_customer_id
ON fixed_deposits(customer_id);

CREATE INDEX IF NOT EXISTS idx_fixed_deposits_status_maturity
ON fixed_deposits(status, maturity_date);

INSERT INTO fixed_deposit_plans (plan_name, tenure_months, annual_rate_bps, minimum_amount_cents, is_active)
SELECT 'Starter 6 Month Deposit', 6, 250, 100000, TRUE
WHERE NOT EXISTS (SELECT 1 FROM fixed_deposit_plans WHERE plan_name = 'Starter 6 Month Deposit');

INSERT INTO fixed_deposit_plans (plan_name, tenure_months, annual_rate_bps, minimum_amount_cents, is_active)
SELECT 'Growth 12 Month Deposit', 12, 325, 500000, TRUE
WHERE NOT EXISTS (SELECT 1 FROM fixed_deposit_plans WHERE plan_name = 'Growth 12 Month Deposit');

INSERT INTO fixed_deposit_plans (plan_name, tenure_months, annual_rate_bps, minimum_amount_cents, is_active)
SELECT 'Premier 24 Month Deposit', 24, 380, 1000000, TRUE
WHERE NOT EXISTS (SELECT 1 FROM fixed_deposit_plans WHERE plan_name = 'Premier 24 Month Deposit');
