use super::Money;
use chrono::{DateTime, Utc};
use sqlx::FromRow;
use uuid::Uuid;

#[derive(Debug, Clone, FromRow)]
pub struct AdminDashboardSummary {
    pub pending_signup_count: i64,
    pub pending_personal_loan_count: i64,
    pub pending_home_loan_count: i64,
    pub active_fixed_deposit_count: i64,
    pub total_customer_count: i64,
}

#[derive(Debug, Clone, FromRow)]
pub struct AdminCustomerApplication {
    pub customer_id: Uuid,
    pub user_id: i64,
    pub full_name: String,
    pub email: String,
    pub phone_number: String,
    pub nric: String,
    pub kyc_status: String,
    pub account_number: Option<String>,
    pub selected_account_type: Option<String>,
    pub created_at: DateTime<Utc>,
}

impl AdminCustomerApplication {
    pub fn created_at_display(&self) -> String {
        self.created_at.format("%d %b %Y").to_string()
    }

    pub fn status_display(&self) -> String {
        match self.kyc_status.as_str() {
            "pending" => "Pending Review".to_string(),
            "approved" => "Approved".to_string(),
            "rejected" => "Rejected".to_string(),
            value => value.replace('_', " "),
        }
    }

    pub fn account_number_display(&self) -> String {
        self.account_number
            .clone()
            .unwrap_or_else(|| "Not created".to_string())
    }

    pub fn account_type_display(&self) -> String {
        self.selected_account_type
            .as_deref()
            .unwrap_or("savings")
            .replace('_', " ")
            .split_whitespace()
            .map(|word| {
                let mut chars = word.chars();
                match chars.next() {
                    Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
                    None => String::new(),
                }
            })
            .collect::<Vec<_>>()
            .join(" ")
    }
}

#[derive(Debug, Clone, FromRow)]
pub struct AdminPersonalLoanRecord {
    pub id: Uuid,
    pub customer_id: Uuid,
    pub customer_name: String,
    pub customer_email: String,
    pub purpose: String,
    pub principal_cents: i64,
    pub annual_rate_bps: i32,
    pub term_months: i32,
    pub monthly_payment_cents: i64,
    pub outstanding_cents: i64,
    pub status: String,
    pub created_at: DateTime<Utc>,
}

impl AdminPersonalLoanRecord {
    pub fn principal_display(&self) -> String {
        Money::from_cents(self.principal_cents).display()
    }

    pub fn monthly_payment_display(&self) -> String {
        Money::from_cents(self.monthly_payment_cents).display()
    }

    pub fn outstanding_display(&self) -> String {
        Money::from_cents(self.outstanding_cents).display()
    }

    pub fn rate_display(&self) -> String {
        format!("{:.2}%", self.annual_rate_bps as f64 / 100.0)
    }

    pub fn created_at_display(&self) -> String {
        self.created_at.format("%d %b %Y").to_string()
    }

    pub fn status_display(&self) -> String {
        match self.status.as_str() {
            "pending" => "Pending Review".to_string(),
            "active" => "Active".to_string(),
            "rejected" => "Rejected".to_string(),
            "fully_paid" => "Fully Paid".to_string(),
            "cancelled" => "Cancelled".to_string(),
            value => value.replace('_', " "),
        }
    }
}

#[derive(Debug, Clone, FromRow)]
pub struct AdminHomeLoanRecord {
    pub id: Uuid,
    pub customer_id: Uuid,
    pub customer_name: String,
    pub customer_email: String,
    pub property_type: String,
    pub property_value_cents: i64,
    pub down_payment_cents: i64,
    pub loan_amount_cents: i64,
    pub annual_rate_bps: i32,
    pub term_years: i32,
    pub monthly_payment_cents: i64,
    pub outstanding_cents: i64,
    pub status: String,
    pub created_at: DateTime<Utc>,
}

impl AdminHomeLoanRecord {
    pub fn property_value_display(&self) -> String {
        Money::from_cents(self.property_value_cents).display()
    }

    pub fn down_payment_display(&self) -> String {
        Money::from_cents(self.down_payment_cents).display()
    }

    pub fn loan_amount_display(&self) -> String {
        Money::from_cents(self.loan_amount_cents).display()
    }

    pub fn monthly_payment_display(&self) -> String {
        Money::from_cents(self.monthly_payment_cents).display()
    }

    pub fn outstanding_display(&self) -> String {
        Money::from_cents(self.outstanding_cents).display()
    }

    pub fn rate_display(&self) -> String {
        format!("{:.2}%", self.annual_rate_bps as f64 / 100.0)
    }

    pub fn created_at_display(&self) -> String {
        self.created_at.format("%d %b %Y").to_string()
    }

    pub fn status_display(&self) -> String {
        match self.status.as_str() {
            "pending" => "Pending Review".to_string(),
            "approved" => "Approved".to_string(),
            "rejected" => "Rejected".to_string(),
            "fully_paid" => "Fully Paid".to_string(),
            value => value.replace('_', " "),
        }
    }
}
